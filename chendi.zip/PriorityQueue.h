/** @file */
#ifndef __PRIORITYQUEUE_H
#define __PRIORITYQUEUE_H

#include "ArrayList.h"
#include "ElementNotExist.h"

/**
 * This is a priority queue based on a priority queue. The
 * elements of the priority queue are ordered according to their
 * natual ordering (operator<), or by a Comparator provided as the
 * second template parameter.
 * The head of this queue is the least element with respect to the
 * specified ordering (different from C++ STL).
 * The iterator does not return the elements in any particular order.
 * But it is required that the iterator will eventually return every
 * element in this queue (even if removals are performed).
 */

/*----------------------------------------------------------------------*/
/**
 * Default Comparator with respect to natural order (operator<).
 */
template <class V>
class Less
{
public:
    bool operator()(const V& a, const V& b)
    {
        return a < b;
    }
};

/**
 * To use this priority queue, users need to either use the
 * default Comparator or provide their own Comparator of this
 * kind.
 * The Comparator should be a class with a public function
 * public: bool operator()(const V&, const V&);
 * overriding the "()" operator.
 * The following code may help you understand how to use a
 * Comparator and, especially, why we override operator().
 */

// #include <iostream>
// using namespace std;
//
// template <class T, class C = Less<T> >
// class Example
// {
// private:
//     C cmp;
// public:
//     bool compare(const T& a, const T& b)
//     {
//         return cmp(a, b);
//     }
// };
//
// int main()
// {
//     Example<int, Less<int> > example; // Less<int> can be omitted.
//     cout << example.compare(1, 2) << endl;
//     cout << example.compare(2, 1) << endl;
// }

/*----------------------------------------------------------------------*/

template <class V, class C = Less<V> >
class PriorityQueue
{
public:
    V *elem;
    int currentLength,maxSize;
    C cmp;
    void doubleSpace()
    {
        V *tmp=elem;
        elem=new V[2*maxSize+1];
        for (int i=0; i<=maxSize; i++) elem[i]=tmp[i];
        maxSize*=2;
        delete [] tmp;
    }
    void sd(int pos)
    {
        int i=pos,j=pos*2;
        while (j<=currentLength)
        {
            if (j<currentLength&&cmp(elem[j+1],elem[j])) j++;
            if (cmp(elem[j],elem[i]))
            {
                V t=elem[j];
                elem[j]=elem[i];
                elem[i]=t;
            }
            else break;
            i=j;
            j=i*2;
        }
    }
    int su(int pos)
    {
        int i=pos,j=pos>>1;
        while (j>0)
        {
            if (cmp(elem[i],elem[j]))
            {
                V t=elem[j];
                elem[j]=elem[i];
                elem[i]=t;
            }
            else return i;
            i=j;
            j=i>>1;
        }
        return 1;
    }
    class Iterator
    {
    private:
        int nextPos,now,jump;
        PriorityQueue *fa;
    public:
        Iterator(PriorityQueue *faclass)
        {
            fa=faclass;
            nextPos=1;
            now=0;
            jump=0;
        }
        /**
         * TODO Returns true if the iteration has more elements.
         */
        bool hasNext()
        {
            return nextPos<=fa->currentLength;
        }

        /**
         * TODO Returns the next element in the iteration.
         * @throw ElementNotExist exception when hasNext() == false
         */
        const V &next()
        {
            if (hasNext())
            {
                now=nextPos;
                int preNextPos=nextPos;
                if (!jump) nextPos++;
                else nextPos=jump,jump=0;
                return fa->elem[preNextPos];
            }
            else throw ElementNotExist();
        }

        /**
         * TODO Removes from the underlying collection the last element
         * returned by the iterator.
         * The behavior of an iterator is unspecified if the underlying
         * collection is modified while the iteration is in progress in
         * any way other than by calling this method.
         * @throw ElementNotExist
         */
        void remove()
        {
            if (now!=0)
            {
                std::swap(fa->elem[now],fa->elem[fa->currentLength]);
                fa->currentLength--;
                if (nextPos>fa->currentLength+1)
                {
                    fa->sd(now);
                    nextPos=fa->currentLength+1;
                }
                else if (now==1)
                {
                    fa->sd(now);
                    nextPos=now;
                }
                else if (nextPos==now+1&&(!fa->cmp(fa->elem[now],fa->elem[now/2])))
                {
                    fa->sd(now);
                    nextPos=now;
                }
                else if (fa->cmp(fa->elem[now],fa->elem[now/2]))
                {
                    jump=nextPos;
                    nextPos=fa->su(now);
                }
                else
                {
                    int i=now,j=now*2,newPos=-1;
                    while (j<=fa->currentLength)
                    {
                        if (j<fa->currentLength&&fa->cmp(fa->elem[j+1],fa->elem[j])) j++;
                        if (fa->cmp(fa->elem[j],fa->elem[i]))
                        {
                            if (j>=nextPos&&newPos==-1) newPos=i;
                            std::swap(fa->elem[i],fa->elem[j]);
                        }
                        else break;
                        i=j;
                        j=i*2;
                    }
                    jump=nextPos;
                    if (newPos==-1) nextPos=i;
                    else nextPos=newPos;
                }
                now=0;
            }
            else throw ElementNotExist();
        }
    };

    /**
     * TODO Constructs an empty priority queue.
     */
    PriorityQueue()
    {
        maxSize=10;
        currentLength=0;
        elem=new V[maxSize+1];
    }

    /**
     * TODO Destructor
     */
    ~PriorityQueue()
    {
        delete [] elem;
    }

    /**
     * TODO Assignment operator
     */
    PriorityQueue &operator=(const PriorityQueue &x)
    {
        currentLength=x.size();
        while (currentLength>maxSize) doubleSpace();
        Iterator itr=(const_cast<PriorityQueue&>(x)).iterator();
        for (int i=1; i<=currentLength; i++) elem[i]=itr.next();
        return *this;
    }

    /**
     * TODO Copy-constructor
     */
    PriorityQueue(const PriorityQueue &x)
    {
        maxSize=10;
        currentLength=0;
        elem=new V[maxSize+1];
        *this=x;
    }

    /**
     * TODO Initializer_list-constructor
     * Constructs a priority queue over the elements in this Array List.
     * Requires to finish in O(n) time.
     */
    PriorityQueue(const ArrayList<V> &x)
    {
        maxSize=10;
        currentLength=0;
        elem=new V[maxSize+1];
        currentLength=x.size();
        while (currentLength>maxSize) doubleSpace();
        for (int i=1; i<=currentLength; i++) elem[i]=x.get(i-1);
        for (int i=currentLength/2; i>=1; i--) sd(i);
    }

    /**
     * TODO Returns an iterator over the elements in this priority queue.
     */
    Iterator iterator()
    {
        return Iterator(this);
    }

    /**
     * TODO Removes all of the elements from this priority queue.
     */
    void clear()
    {
        currentLength=0;
    }

    /**
     * TODO Returns a const reference to the front of the priority queue.
     * If there are no elements, this function should throw ElementNotExist exception.
     * @throw ElementNotExist
     */
    const V &front() const
    {
        if (currentLength==0) throw ElementNotExist();
        return elem[1];
    }

    /**
     * TODO Returns true if this PriorityQueue contains no elements.
     */
    bool empty() const
    {
        return currentLength==0;
    }

    /**
     * TODO Add an element to the priority queue.
     */
    void push(const V &value)
    {
        if (currentLength==maxSize) doubleSpace();
        currentLength++;
        elem[currentLength]=value;
        su(currentLength);
    }

    /**
     * TODO Removes the top element of this priority queue if present.
     * If there is no element, throws ElementNotExist exception.
     * @throw ElementNotExist
     */
    void pop()
    {
        if (currentLength==0) throw ElementNotExist();
        elem[1]=elem[currentLength];
        currentLength--;
        sd(1);
    }

    /**
     * TODO Returns the number of key-value mappings in this map.
     */
    int size() const
    {
        return currentLength;
    }
};

#endif
