/** @file */
#ifndef __ARRAYLIST_H
#define __ARRAYLIST_H

#include "IndexOutOfBound.h"
#include "ElementNotExist.h"

/**
 * The ArrayList is just like vector in C++.
 * You should know that "capacity" here doesn't mean how many elements are now in this list, where it means
 * the length of the array of your internal implemention
 *
 * The iterator iterates in the order of the elements being loaded into this list
 */
template <class T>
class ArrayList
{
public:
    int maxSize,currentLength;
    T *elem;
    void doubleSpace()
    {
        T *tmp=elem;
        elem=new T[2*maxSize];
        for (int i=0;i<maxSize;i++) elem[i]=tmp[i];
        maxSize*=2;
        delete [] tmp;
    }
    class Iterator
    {
    private:
        int nextPos,nowPos;
        ArrayList *fa;
    public:
        Iterator(ArrayList *faclass)
        {
            nextPos=0;
            nowPos=-1;
            fa=faclass;
        }
        /**
         * TODO Returns true if the iteration has more elements.
         */
        bool hasNext()
        {
            return nextPos<fa->currentLength;
        }
        /**
         * TODO Returns the next element in the iteration.
         * @throw ElementNotExist exception when hasNext() == false
         */
        const T &next()
        {
            if (hasNext())
            {
                nowPos=nextPos;
                return fa->elem[nextPos++];
            }
            else throw ElementNotExist();
        }
        /**
         * TODO Removes from the underlying collection the last element
         * returned by the iterator
         * The behavior of an iterator is unspecified if the underlying
         * collection is modified while the iteration is in progress in
         * any way other than by calling this method.
         * @throw ElementNotExist
         */
        void remove()
        {
            if (nowPos!=-1)
            {
                for (int i=nextPos;i<fa->currentLength;i++) fa->elem[i-1]=fa->elem[i];
                fa->currentLength--;
                nextPos--;
                nowPos=-1;
            }
            else throw ElementNotExist();
        }
    };
    friend class Iterator;
    /**
     * TODO Constructs an empty array list.
     */
    ArrayList()
    {
        maxSize=10;
        currentLength=0;
        elem=new T[maxSize];
    }
    /**
     * TODO Destructor
     */
    ~ArrayList()
    {
        delete [] elem;
    }
    /**
     * TODO Assignment operator
     */
    ArrayList& operator=(const ArrayList& x)
    {
        if (&x==this) return *this;
        currentLength=x.size();
        while (currentLength>maxSize)
        doubleSpace();
        for (int i=0;i<currentLength;i++) elem[i]=x.get(i);
        return *this;
    }
    /**
     * TODO Copy-constructor
     */
    ArrayList(const ArrayList<T>& x)
    {
        maxSize=10;
        currentLength=0;
        elem=new T[maxSize];
        *this=x;
    }

    /**
     * TODO Appends the specified element to the end of this list.
     * Always returns true.
     */
    bool add(const T& e)
    {
        if (currentLength==maxSize) doubleSpace();
        elem[currentLength++]=e;
        return true;
    }
    /**
     * TODO Inserts the specified element to the specified position in this list.
     * The range of index parameter is [0, size], where index=0 means inserting to the head,
     * and index=size means appending to the end.
     * @throw IndexOutOfBound
     */
    void add(int index, const T& element)
    {
        if (index<0||index>currentLength+1) throw IndexOutOfBound();
        if (currentLength+1>maxSize) doubleSpace();
        for (int i=currentLength-1;i>=index;i--) elem[i+1]=elem[i];
        currentLength++;
        elem[index]=element;
    }
    /**
     * TODO Removes all of the elements from this list.
     */
    void clear()
    {
        currentLength=0;
    }

    /**
     * TODO Returns true if this list contains the specified element.
     */
    bool contains(const T& e) const
    {
        for (int i=0;i<currentLength;i++) if (elem[i]==e) return true;
        return false;
    }
    /**
     * TODO Returns a const reference to the element at the specified position in this list.
     * The index is zero-based, with range [0, size).
     * @throw IndexOutOfBound
     */
    const T& get(int index) const
    {
        if (index<0||index>=currentLength) throw IndexOutOfBound();
        return elem[index];
    }

    /**
     * TODO Returns true if this list contains no elements.
     */
    bool isEmpty() const
    {
        return currentLength==0;
    }

    /**
     * TODO Removes the element at the specified position in this list.
     * The index is zero-based, with range [0, size).
     * @throw IndexOutOfBound
     */
    void removeIndex(int index)
    {
        if (index<0||index>=currentLength) throw IndexOutOfBound();
        for (int i=index;i<currentLength-1;i++) elem[i]=elem[i+1];
        currentLength--;
    }
    /**
     * TODO Removes the first occurrence of the specified element from this list, if it is present.
     * Returns true if it was present in the list, otherwise false.
     */
    bool remove(const T &e)
    {
        for (int i=0;i<currentLength;i++)
        if (elem[i]==e)
        {
            removeIndex(i);
            return true;
        }
        return false;
    }

    /**
     * TODO Replaces the element at the specified position in this list with the specified element.
     * The index is zero-based, with range [0, size).
     * @throw IndexOutOfBound
     */
    void set(int index, const T &element)
    {
        if (index<0||index>=currentLength) throw IndexOutOfBound();
        elem[index]=element;
    }
    /**
     * TODO Returns the number of elements in this list.
     */
    int size() const
    {
        return currentLength;
    }
    /**
     * TODO Returns an iterator over the elements in this list.
     */
    Iterator iterator()
    {
        return Iterator(this);
    }
};
#endif
