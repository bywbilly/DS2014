/** @file */
#ifndef __DEQUE_H
#define __DEQUE_H

#include "ElementNotExist.h"
#include "IndexOutOfBound.h"

/**
 * An deque is a linear collection that supports element insertion and removal at both ends.
 * The name deque is short for "double ended queue" and is usually pronounced "deck".
 * Remember: all functions but "contains" and "clear" should be finished in O(1) time.
 *
 * You need to implement both iterators in proper sequential order and ones in reverse sequential order.
 */
template <class T>
class Deque
{
public:
    T *elem;
    int maxSize,currentLength,head,tail;
    int prePos(int pos) const
    {
        if (pos>0) return pos-1;
        return maxSize-1;
    }
    int nextPos(int pos) const
    {
        if (pos<maxSize-1) return pos+1;
        return 0;
    }
    void doubleSpace()
    {
        T *tmp=elem;
        elem=new T[2*maxSize];
        int cnt=0;
        while (head!=tail)
        {
            elem[cnt++]=tmp[head];
            head=nextPos(head);
        }
        if (currentLength>0)
        {
            elem[cnt++]=tmp[tail];
            head=0;
            tail=cnt-1;
        }
        else head=tail=-1;
        maxSize*=2;
        delete [] tmp;
    }
    class Iterator
    {
    private:
        int nextP,now;
        bool exist,rev;
        Deque *fa;
    public:
        Iterator(bool itrRev,Deque *faClass)
        {
            fa=faClass;
            rev=itrRev;
            if (!rev)
            {
                nextP=fa->head;
                now=-1;
            }
            else
            {
                nextP=fa->tail;
                now=-1;
            }
            exist=false;
        }
        /**
         * TODO Returns true if the iteration has more elements.
         */
        bool hasNext()
        {
            if (fa->currentLength==0) return false;
            if (!rev) return now!=fa->tail;
            return now!=fa->head;
        }
        //ѭ����head,tail������
        /**
         * TODO Returns the next element in the iteration.
         * @throw ElementNotExist exception when hasNext() == false
         */
        const T &next()
        {
            if (hasNext())
            {
                now=nextP;
                if (!rev) nextP=fa->nextPos(nextP);
                else nextP=fa->prePos(nextP);
                exist=true;
                return fa->elem[now];
            }
            else throw ElementNotExist();
        }

        /**
         * TODO Removes from the underlying collection the last element
         * returned by the iterator
         * The behavior of an iterator is unspecified if the underlying
         * collection is modified while the iteration is in progress in
         * any way other than by calling this method.
         * @throw ElementNotExist
         */
        void remove()
        {
            if (exist)
            {
                for (int i=now; i!=fa->tail; i=fa->nextPos(i)) fa->elem[i]=fa->elem[fa->nextPos(i)];
                fa->currentLength--;
                fa->tail=fa->prePos(fa->tail);
                if (fa->currentLength==0)
                {
                    fa->head=fa->tail=-1;
                }
                if (!rev)
                {
                    nextP=now;
                    now=fa->prePos(nextP);
                }
                else
                {
                    now=fa->nextPos(nextP);
                }
                exist=false;
            }
            else throw ElementNotExist();
        }
    };

    /**
     * TODO Constructs an empty deque.
     */
    Deque()
    {
        maxSize=10;
        currentLength=0;
        elem=new T[maxSize];
        head=-1;
        tail=-1;
    }

    /**
     * TODO Destructor
     */
    ~Deque()
    {
        delete [] elem;
    }

    /**
     * TODO Assignment operator
     */
    Deque<T>& operator=(const Deque<T>& x)
    {
        while (x.size()>maxSize) doubleSpace();
        currentLength=x.size();
        for (int i=0; i<currentLength; i++) elem[i]=x.get(i);
        tail=currentLength-1;
        head=0;
        if (tail==-1) head=-1;
        return *this;
    }

    /**
     * TODO Copy-constructor
     */
    Deque(const Deque<T>& x)
    {
        maxSize=10;
        currentLength=0;
        elem=new T[maxSize];
        head=-1;
        tail=-1;
        *this=x;
    }

    /**
     * TODO Inserts the specified element at the front of this deque.
     */
    void addFirst(const T& e)
    {
        if (head==nextPos(tail)) doubleSpace();
        if (head==-1)
        {
            head=tail=0;
            elem[0]=e;
        }
        else
        {
            head=prePos(head);
            elem[head]=e;
        }
        currentLength++;
    }

    /**
     * TODO Inserts the specified element at the end of this deque.
     */
    void addLast(const T& e)
    {
        if (head==nextPos(tail)) doubleSpace();
        if (head==-1)
        {
            head=tail=0;
            elem[0]=e;
        }
        else
        {
            tail=nextPos(tail);
            elem[tail]=e;
        }
        currentLength++;
    }

    /**
     * TODO Returns true if this deque contains the specified element.
     */
    bool contains(const T& e) const
    {
        if (currentLength==0) return false;
        for (int i=head; i!=tail; i=nextPos(i)) if (elem[i]==e) return true;
        return elem[tail]==e;
    }

    /**
     * TODO Removes all of the elements from this deque.
     */
    void clear()
    {
        head=-1;
        tail=-1;
        currentLength=0;
    }

    /**
     * TODO Returns true if this deque contains no elements.
     */
    bool isEmpty() const
    {
        return currentLength==0;
    }

    /**
     * TODO Retrieves, but does not remove, the first element of this deque.
     * @throw ElementNotExist
     */
    const T& getFirst()
    {
        if (currentLength>0) return elem[head];
        else throw ElementNotExist();
    }

    /**
     * TODO Retrieves, but does not remove, the last element of this deque.
     * @throw ElementNotExist
     */
    const T& getLast()
    {
        if (currentLength>0) return elem[tail];
        else throw ElementNotExist();
    }

    /**
     * TODO Removes the first element of this deque.
     * @throw ElementNotExist
     */
    void removeFirst()
    {
        if (currentLength>0)
        {
            head=nextPos(head);
            currentLength--;
            if (currentLength==0)
            {
                head=tail=-1;
            }
        }
        else throw ElementNotExist();
    }

    /**
     * TODO Removes the last element of this deque.
     * @throw ElementNotExist
     */
    void removeLast()
    {
        if (currentLength>0)
        {
            tail=prePos(tail);
            currentLength--;
            if (currentLength==0)
            {
                head=tail=-1;
            }
        }
        else throw ElementNotExist();
    }

    /**
     * TODO Returns a const reference to the element at the specified position in this deque.
     * The index is zero-based, with range [0, size).
     * @throw IndexOutOfBound
     */
    const T& get(int index) const
    {
        if (index<0||index>=currentLength) throw IndexOutOfBound();
        int pos=head+index-maxSize;
        if (head+index<maxSize) pos=head+index;
        return elem[pos];
    }

    /**
     * TODO Replaces the element at the specified position in this deque with the specified element.
     * The index is zero-based, with range [0, size).
     * @throw IndexOutOfBound
     */
    void set(int index, const T& e)
    {
        if (index<0||index>=currentLength) throw IndexOutOfBound();
        int pos=head+index-maxSize;
        if (head+index<maxSize) pos=head+index;
        elem[pos]=e;
    }

    /**
     * TODO Returns the number of elements in this deque.
     */
    int size() const
    {
        return currentLength;
    }

    /**
     * TODO Returns an iterator over the elements in this deque in proper sequence.
     */
    Iterator iterator()
    {
        return Iterator(false,this);
    }

    /**
     * TODO Returns an iterator over the elements in this deque in reverse sequential order.
     */
    Iterator descendingIterator()
    {
        return Iterator(true,this);
    }
};

#endif
