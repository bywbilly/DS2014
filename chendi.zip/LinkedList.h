/** @file */
#ifndef __LINKEDLIST_H
#define __LINKEDLIST_H

#include "IndexOutOfBound.h"
#include "ElementNotExist.h"

/**
 * A linked list.
 *
 * The iterator iterates in the order of the elements being loaded into this list.
 */
template <class T>
class LinkedList
{
public:
    struct node
    {
        T data;
        node *nextPos,*prePos;
        node()
        {
            nextPos=prePos=NULL;
        }
    };
    node *head,*tail;
    int currentLength;

    class Iterator
    {
    private:
        node *nowPos,*nextPos,*prePos;
        bool exist;
        LinkedList*fa;
    public:
        Iterator(LinkedList *faclass)
        {
            fa=faclass;
            exist=false;
            nowPos=prePos=NULL;
            nextPos=fa->head;
        }
        /**
         * TODO Returns true if the iteration has more elements.
         */
        bool hasNext()
        {
            if (fa->currentLength==0) return false;
            return nextPos!=NULL;
        }

        /**
         * TODO Returns the next element in the iteration.
         * @throw ElementNotExist exception when hasNext() == false
         */
        const T &next()
        {
            if (hasNext())
            {
                prePos=nowPos;
                nowPos=nextPos;
                nextPos=nowPos->nextPos;
                exist=true;
                return nowPos->data;
            }
            else throw ElementNotExist();
        }

        /**
         * TODO Removes from the underlying collection the last element
         * returned by the iterator
         * The behavior of an iterator is unspecified if the underlying
         * collection is modified while the iteration is in progress in
         * any way other than by calling this method.
         * @throw ElementNotExist
         */
        void remove()
        {
            if (exist)
            {
                if (nowPos==fa->head) fa->head=fa->head->nextPos;
                if (nowPos==fa->tail) fa->tail=fa->tail->prePos;
                if (nowPos->prePos) nowPos->prePos->nextPos=nowPos->nextPos;
                if (hasNext()) nowPos->nextPos->prePos=nowPos->prePos;
                fa->currentLength--;
                if (fa->currentLength==0) fa->head=fa->tail=NULL;
                node *tmp=nowPos;
                nowPos=NULL;
                delete tmp;
                exist=false;
            }
            else throw ElementNotExist();
        }
    };

    /**
     * TODO Constructs an empty linked list
     */
    LinkedList()
    {
        currentLength=0;
        head=tail=NULL;
    }

    /**
     * TODO Assignment operator
     */
    LinkedList<T>& operator=(const LinkedList<T> &c)
    {
        if (&c==this) return *this;
        currentLength=c.size();
        node *t=c.head;
        for (int i=0;i<currentLength;i++)
        {

            if (head==NULL)
            {
                head=tail=new node();
                head->data=t->data;
                t=t->nextPos;
            }
            else
            {
                node *tmp=new node();
                tmp->data=t->data;
                t=t->nextPos;
                tmp->prePos=tail;
                tail->nextPos=tmp;
                tail=tmp;
            }
        }
        return *this;
    }

    /**
     * TODO Copy constructor
     */
    LinkedList(const LinkedList<T> &c)
    {
        currentLength=0;
        head=tail=NULL;
        *this=c;
    }

    /**
     * TODO Desturctor
     */
    ~LinkedList()
    {
        node *tmp;
        while (head!=tail)
        {
            tmp=head;
            head=head->nextPos;
            delete tmp;
        }
        delete head;
        currentLength=0;
        head=tail=NULL;
    }

    /**
     * TODO Appends the specified element to the end of this list.
     * Always returns true.
     */
    bool add(const T& e)
    {
        node *tmp=new node();
        tmp->data=e;
        tmp->prePos=tail;
        if (tail) tail->nextPos=tmp;
        else head=tail=tmp;
        tail=tmp;
        currentLength++;
        return true;
    }

    /**
     * TODO Inserts the specified element to the beginning of this list.
     */
    void addFirst(const T& elem)
    {
        node *tmp=new node();
        tmp->data=elem;
        tmp->nextPos=head;
        if (head) head->prePos=tmp;
        else head=tail=tmp;
        head=tmp;
        currentLength++;
    }

    /**
     * TODO Insert the specified element to the end of this list.
     * Equivalent to add.
     */
    void addLast(const T &elem) { add(elem);}

    /**
     * TODO Inserts the specified element to the specified position in this list.
     * The range of index parameter is [0, size], where index=0 means inserting to the head,
     * and index=size means appending to the end.
     * @throw IndexOutOfBound
     */
    void add(int index, const T& element)
    {
        if (index<0||index>currentLength+1) throw IndexOutOfBound();
        node *tmp=head;
        for (int i=0;i<index;i++) tmp=tmp->nextPos;
        node *ne=new node();
        ne->data=element;
        ne->nextPos=tmp;
        if (tmp)
        {
            ne->prePos=tmp->prePos;
            if (tmp->prePos) tmp->prePos->nextPos=ne;
            else head=ne;
        }
        else
        {
            ne->prePos=tail;
            if (tail) tail->nextPos=ne,tail=ne;
            else
            {
                head=tail=ne;
            }
        }
        if (tmp) tmp->prePos=ne;
        currentLength++;
    }

    /**
     * TODO Removes all of the elements from this list.
     */
    void clear()
    {
        node *tmp;
        while (head!=tail)
        {
            tmp=head;
            head=head->nextPos;
            delete tmp;
        }
        delete head;
        head=tail=NULL;
        currentLength=0;
    }

    /**
     * TODO Returns true if this list contains the specified element.
     */
    bool contains(const T& e) const
    {
        node *tmp=head;
        while (tmp)
        {
            if (tmp->data==e) return true;
            tmp=tmp->nextPos;
        }
        return false;
    }

    /**
     * TODO Returns a const reference to the element at the specified position in this list.
     * The index is zero-based, with range [0, size).
     * @throw IndexOutOfBound
     */
    const T& get(int index) const
    {
        if (index<0||index>=currentLength) throw IndexOutOfBound();
        node *tmp=head;
        for (int i=0;i<index;i++) tmp=tmp->nextPos;
        return tmp->data;
    }

    /**
     * TODO Returns a const reference to the first element.
     * @throw ElementNotExist
     */
    const T& getFirst() const
    {
        if (currentLength==0) throw ElementNotExist();
        return head->data;
    }

    /**
     * TODO Returns a const reference to the last element.
     * @throw ElementNotExist
     */
    const T& getLast() const
    {
         if (currentLength==0) throw ElementNotExist();
         return tail->data;
    }

    /**
     * TODO Returns true if this list contains no elements.
     */
    bool isEmpty() const {return currentLength==0;}

    /**
     * TODO Removes the element at the specified position in this list.
     * The index is zero-based, with range [0, size).
     * @throw IndexOutOfBound
     */
    void removeIndex(int index)
    {
        if (index<0||index>=currentLength) throw IndexOutOfBound();
        node *tmp=head;
        for (int i=0;i<index;i++) tmp=tmp->nextPos;
        if (head==tmp) head=head->nextPos;
        if (tail==tmp) tail=tail->prePos;
        if (tmp->prePos) tmp->prePos->nextPos=tmp->nextPos;
        if (tmp->nextPos) tmp->nextPos->prePos=tmp->prePos;
        currentLength--;
        delete tmp;
        if (currentLength==0) head=tail=NULL;
    }

    /**
     * TODO Removes the first occurrence of the specified element from this list, if it is prePossent.
     * Returns true if it was prePossent in the list, otherwise false.
     */
    bool remove(const T &e)
    {
        node *tmp=head;
        for (int i=0;i<currentLength;i++)
        {
            if (tmp->data==e)
            {
                removeIndex(i);
                return true;
            }
            tmp=tmp->nextPos;
        }
        return false;
    }

    /**
     * TODO Removes the first element from this list.
     * @throw ElementNotExist
     */
    void removeFirst()
    {
        if (currentLength==0) throw ElementNotExist();
        node *tmp=head;
        head=head->nextPos;
        delete tmp;
        currentLength--;
        if (currentLength==0) head=tail=NULL;
    }

    /**
     * TODO Removes the last element from this list.
     * @throw ElementNotExist
     */
    void removeLast()
    {
        if (currentLength==0) throw ElementNotExist();
        node *tmp=tail;
        tail=tail->prePos;
        delete tmp;
        currentLength--;
        if (currentLength==0) head=tail=NULL;
    }

    /**
     * TODO Replaces the element at the specified position in this list with the specified element.
     * The index is zero-based, with range [0, size).
     * @throw IndexOutOfBound
     */
    void set(int index, const T &element)
    {
        if (index<0||index>=currentLength) throw IndexOutOfBound();
        node *tmp=head;
        for (int i=0;i<index;i++) tmp=tmp->nextPos;
        tmp->data=element;
    }

    /**
     * TODO Returns the number of elements in this list.
     */
    int size() const {return currentLength;}

    /**
     * TODO Returns an iterator over the elements in this list.
     */
    Iterator iterator() {return Iterator(this);}
};

#endif
