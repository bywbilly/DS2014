/** @file */

#ifndef __HASHMAP_H
#define __HASHMAP_H

#include "ElementNotExist.h"

/**
 * HashMap is a map implemented by hashing. Also, the 'capacity' here means the
 * number of buckets in your internal implemention, not the current number of the
 * elements.
 *
 * Template argument H are used to specify the hash function.
 * H should be a class with a static function named ``hashCode'',
 * which takes a parameter of type K and returns a value of type int.
 * For example, the following class
 * @code
 *      class Hashint {
 *      public:
 *          static int hashCode(int obj) {
 *              return obj;
 *          }
 *      };
 * @endcode
 * specifies an hash function for integers. Then we can define:
 * @code
 *      HashMap<int, int, Hashint> hash;
 * @endcode
 *
 * Hash function passed to this class should observe the following rule: if two keys
 * are equal (which means key1 == key2), then the hash code of them should be the
 * same. However, it is not generally required that the hash function should work in
 * the other direction: if the hash code of two keys are equal, the two keys could be
 * different.
 *
 * Note that the correctness of HashMap should not rely on the choice of hash function.
 * This is to say that, even the given hash function always returns the same hash code
 * for all keys (thus causing a serious collision), methods of HashMap should still
 * function correctly, though the performance will be poor in this case.
 *
 * The order of iteration could be arbitary in HashMap. But it should be guaranteed
 * that each (key, value) pair be iterated exactly once.
 */
template <class K, class V, class H>
class HashMap
{
public:
    int calc(int x) const
    {
        return (x%maxSize+maxSize)%maxSize;
    }
    class Entry
    {
    friend class HashMap<K,V,H>;
    private:
        K key;
        V value;
    public:
        Entry(K k, V v)
        {
            key = k;
            value = v;
        }
        Entry()
        {

        }
        K getKey() const
        {
            return key;
        }

        V getValue() const
        {
            return value;
        }
    };
public:
    int maxSize,cnt;
    int *nextPos,*nowPos;
    Entry *elem;
    void doubleSpace();
    class Iterator
    {
    private:
        int nextP,now,snt;
        Entry *data;
    public:
        Iterator(const HashMap *faclass)
        {
            now=-1;
            nextP=0;
            snt=faclass->cnt;
            data=faclass->elem;
        }
        /**
         * TODO Returns true if the iteration has more elements.
         */
        bool hasNext()
        {
            return nextP<snt;
        }
        /**
         * TODO Returns the next element in the iteration.
         * @throw ElementNotExist exception when hasNext() == false
         */
        const Entry &next()
        {
            if (hasNext())
            {
                now=nextP;
                return data[nextP++];
            }
            else throw ElementNotExist();
        }
    };
    void put(const K &key, const V &value);
    /**
     * TODO Constructs an empty hash map.
     */
    HashMap()
    {
        maxSize=10;
        cnt=0;
        elem=new Entry[maxSize];
        nextPos=new int[maxSize];
        nowPos=new int[maxSize];
        for (int i=0;i<maxSize;i++) nextPos[i]=nowPos[i]=-1;
    }

    /**
     * TODO Destructor
     */
    ~HashMap()
    {
        delete [] elem;
        delete [] nextPos;
        delete [] nowPos;
    }

    /**
     * TODO Assignment operator
     */
    HashMap<K,V,H> &operator=(const HashMap<K,V,H> &x)
    {
        if (&x==this) return *this;
        Iterator itr=x.iterator();
        int n=x.size();
        while (n>maxSize) doubleSpace();
        for (int i=0; i<maxSize; i++) nextPos[i]=nowPos[i]=-1;
        cnt=0;
        for (int i=0; i<n; i++)
        {
            Entry tmp=itr.next();
            put(tmp.key,tmp.value);
        }
        return *this;
    }

    /**
     * TODO Copy-constructor
     */
    HashMap(const HashMap<K,V,H> &x)
    {
        maxSize=10;
        cnt=0;
        elem=new Entry[maxSize];
        nextPos=new int[maxSize];
        nowPos=new int[maxSize];
        for (int i=0;i<maxSize;i++) nextPos[i]=nowPos[i]=-1;
        *this=x;
    }

    /**
     * TODO Returns an iterator over the elements in this map.
     */
    Iterator iterator() const
    {
        return Iterator(this);
    }

    /**
     * TODO Removes all of the mappings from this map.
     */
    void clear()
    {
        for (int i=0; i<maxSize; i++) nextPos[i]=nowPos[i]=-1;
        cnt=0;
    }

    /**
     * TODO Returns true if this map contains a mapping for the specified key.
     */
    bool containsKey(const K &key) const
    {
        int t=calc(H::hashCode(key));
        for (int i=nowPos[t]; i!=-1; i=nextPos[i])
            if (elem[i].key==key) return true;
        return false;
    }

    /**
     * TODO Returns true if this map maps one or more keys to the specified value.
     */
    bool containsValue(const V &value) const
    {
        for (int i=0; i<cnt; i++) if (elem[i].value==value) return true;
        return false;
    }

    /**
     * TODO Returns a const reference to the value to which the specified key is mapped.
     * If the key is not present in this map, this function should throw ElementNotExist exception.
     * @throw ElementNotExist
     */
    const V &get(const K &key) const
    {
        if (containsKey(key))
        {
            int t=calc(H::hashCode(key));
            for (int i=nowPos[t]; i!=-1; i=nextPos[i])
                if (elem[i].key==key) return elem[i].value;
        }
        else throw ElementNotExist();
    }

    /**
     * TODO Returns true if this map contains no key-value mappings.
     */
    bool isEmpty() const
    {
        return cnt==0;
    }

    /**
     * TODO Associates the specified value with the specified key in this map.
     */


    /**
     * TODO Removes the mapping for the specified key from this map if present.
     * If there is no mapping for the specified key, throws ElementNotExist exception.
     * @throw ElementNotExist
     */
    void remove(const K &key)
    {
        if (containsKey(key))
        {
            int t=calc(H::hashCode(key)),tpos=-1;
            for (int i=nowPos[t]; i!=-1; i=nextPos[i])
                if (elem[i].key==key)
                {
                    if (tpos==-1)
                    {
                        nowPos[t]=nextPos[i];
                    }
                    else
                    {
                        nextPos[tpos]=nextPos[i];
                    }
                    cnt--;
                    if (i==cnt)
                    {
                        nextPos[cnt]=-1;
                        break;
                    }
                    elem[i]=elem[cnt];
                    nextPos[i]=nextPos[cnt];
                    nextPos[cnt]=-1;
                    int tt=calc(H::hashCode(elem[cnt].key));
                    bool get=false;
                    for (int j=nowPos[tt];j!=-1;j=nextPos[j])
                    if (nextPos[j]==cnt)
                    {
                        nextPos[j]=i;
                        get=true;
                        break;
                    }
                    if (!get) nowPos[tt]=i;
                    break;
                }
                else tpos=i;
        }
        else throw ElementNotExist();
    }

    /**
     * TODO Returns the number of key-value mappings in this map.
     */
    int size() const
    {
        return cnt;
    }
};
template <class K, class V, class H>
void HashMap<K,V,H>::put(const K &key, const V &value)
{
    if (!containsKey(key))
    {
        if (cnt==maxSize) doubleSpace();
        int t=calc(H::hashCode(key));
        nextPos[cnt]=nowPos[t];
        nowPos[t]=cnt;
        elem[cnt].key=key;
        elem[cnt].value=value;
        cnt++;
    }
    else
    {
        int t=calc(H::hashCode(key));
        for (int i=nowPos[t]; i!=-1; i=nextPos[i])
            if (elem[i].key==key)
            {
                elem[i].value=value;
                break;
            }
    }
}
template <class K, class V, class H>
void HashMap<K,V,H>::doubleSpace()
{
    maxSize*=2;
    int *tmp2=nextPos;
    nextPos=new int[maxSize];
    for (int i=0; i<maxSize; i++) nextPos[i]=-1;
    delete [] tmp2;

    int *tmp3=nowPos;
    nowPos=new int[maxSize];
    for (int i=0; i<maxSize; i++) nowPos[i]=-1;
    delete [] tmp3;

    Entry *tmp1=elem;
    elem=new Entry[maxSize];
    cnt=0;
    for (int i=0; i<maxSize/2; i++) put(tmp1[i].key,tmp1[i].value);
    delete [] tmp1;
}
#endif
