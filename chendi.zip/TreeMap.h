/** @file */
#ifndef __TREEMAP_H
#define __TREEMAP_H

#include "ElementNotExist.h"

/**
 * TreeMap is the balanced-tree implementation of map. The iterators must
 * iterate through the map in the natural order (operator<) of the key.
 */
template<class K, class V>
class TreeMap
{
public:
    class Entry
    {
        friend class TreeMap<K,V>;
    private:
        K key;
        V value;
        Entry *fa,*child[2];
        int flag;
    public:
        Entry(K k, V v)
        {
            key = k;
            value = v;
            fa=child[0]=child[1]=NULL;
            flag=0;
        }
        Entry()
        {
            fa=child[0]=child[1]=NULL;
            flag=0;
        }
        K getKey() const
        {
            return key;
        }

        V getValue() const
        {
            return value;
        }
    };
    Entry *ROOT,*min,*max;
    int cnt;
    void clearTree(Entry *p)
    {
        if (!p) return;
        Entry **elem=new Entry*[cnt+10];
        int head=0,tail=0;
        elem[head]=p;
        Entry *tmp;
        while (head<=tail)
        {
            tmp=elem[head];
            if (tmp->child[0]) elem[++tail]=tmp->child[0];
            if (tmp->child[1]) elem[++tail]=tmp->child[1];
            delete tmp;
            head++;
        }
        delete [] elem;
    }
    int f(Entry *p) const
    {
        return p==p->fa->child[1];
    }
    void rotate(Entry *p) const
    {
        Entry *fa=p->fa;
        int idx=f(p);
        fa->child[idx]=p->child[1^idx];
        if (p->child[1^idx]) p->child[1^idx]->fa=fa;
        p->fa=fa->fa;
        if (fa->fa) fa->fa->child[f(fa)]=p;
        p->child[1^idx]=fa;
        fa->fa=p;
    }
    void splay(Entry *p,Entry *root) const
    {
        if (!p||!root||p==root) return;
        Entry *fa=root->fa;
        while (p->fa!=fa)
        {
            if (p->fa->fa==fa) rotate(p);
            else if (f(p)==f(p->fa))
            {
                rotate(p->fa);
                rotate(p);
            }
            else
            {
                rotate(p);
                rotate(p);
            }
        }
    }
    Entry *find(Entry *p,K key) const
    {
        Entry *tmp;
        while (p)
        {
            tmp=p;
            if (p->flag==0&&(!(p->key<key))&&(!(key<p->key))) break;
            if (p->flag<0||(p->flag==0&&p->key<key)) p=p->child[1];
            else p=p->child[0];
        }
        splay(tmp,ROOT->child[1]);
        if (tmp->flag==0&&(!(tmp->key<key))&&(!(key<tmp->key))) return tmp;
        return NULL;
    }
    Entry *search(Entry *p,V value) const
    {
        if (!p) return NULL;
        Entry **elem=new Entry*[cnt+10];
        int head=0,tail=0;
        elem[head]=p;
        Entry *tmp;
        while (head<=tail)
        {
            tmp=elem[head];
            if (tmp->value==value) break;
            if (tmp->child[0]) elem[++tail]=tmp->child[0];
            if (tmp->child[1]) elem[++tail]=tmp->child[1];
            head++;
        }
        delete [] elem;
        if (tmp->value==value) return tmp;
        return NULL;
    }
    void insert(Entry *p,Entry *q)
    {
        Entry *tmp;
        while (p)
        {
            tmp=p;
            if ((p->flag<q->flag)||(p->flag==q->flag&&p->key<q->key)) p=p->child[1];
            else p=p->child[0];
        }
        q->fa=tmp;
        if ((tmp->flag<q->flag)||(tmp->flag==q->flag&&tmp->key<q->key)) tmp->child[1]=q;
        else tmp->child[0]=q;
        splay(q,ROOT->child[1]);
    }
    class Iterator
    {
    public:
        Entry *nextPos,*ROOT,*min,*max;
        const TreeMap *fa;
        Iterator(const TreeMap *faclass)
        {
            fa=faclass;
            ROOT=faclass->ROOT;
            min=faclass->min;
            max=faclass->max;
            fa->splay(min,ROOT->child[1]);
            nextPos=min->child[1];
            while (nextPos->child[0]) nextPos=nextPos->child[0];
            fa->splay(nextPos,ROOT->child[1]);
        }
        /**
         * TODO Returns true if the iteration has more elements.
         */
        bool hasNext()
        {
            return nextPos!=max;
        }

        /**
         * TODO Returns the next element in the iteration.
         * @throw ElementNotExist exception when hasNext() == false
         */
        const Entry &next()
        {
            if (hasNext())
            {
                Entry *tmp=nextPos;
                fa->splay(nextPos,ROOT->child[1]);
                fa->splay(max,ROOT->child[1]->child[1]);
                if (nextPos->child[1]->child[0]==NULL) nextPos=max;
                else
                {
                    Entry *t=nextPos->child[1]->child[0];
                    while (t->child[0]) t=t->child[0];
                    nextPos=t;
                }
                return *tmp;
            }
            else throw ElementNotExist();
        }
    };
    void put(const K &key, const V &value);
    /**
     * TODO Constructs an empty tree map.
     */
    TreeMap()
    {
        cnt=0;
        ROOT=new Entry();
        ROOT->flag=-2;
        min=new Entry();
        min->flag=-1;
        max=new Entry();
        max->flag=1;
        insert(ROOT,min);
        insert(ROOT,max);
    }
    /**
     * TODO Destructor
     */
    ~TreeMap()
    {
        clearTree(ROOT);
    }

    /**
     * TODO Assignment operator
     */
    TreeMap &operator=(const TreeMap &x)
    {
        int snt=x.size();
        clearTree(ROOT->child[1]);
        ROOT->child[1]=NULL;
        cnt=0;
        min=new Entry();
        min->flag=-1;
        max=new Entry();
        max->flag=1;
        insert(ROOT,min);
        insert(ROOT,max);
        Iterator itr=x.iterator();
        for (int i=0; i<snt; i++)
        {
            Entry Next=itr.next();
            put(Next.key,Next.value);
        }
        return *this;
    }

    /**
     * TODO Copy-constructor
     */
    TreeMap(const TreeMap &x)
    {
        ROOT=new Entry();
        ROOT->flag=-2;
        cnt=0;
        *this=x;
    }

    /**
     * TODO Returns an iterator over the elements in this map.
     */
    Iterator iterator() const
    {
        return Iterator(this);
    }

    /**
     * TODO Removes all of the mappings from this map.
     */
    void clear()
    {
        clearTree(ROOT->child[1]);
        ROOT->child[1]=NULL;
        cnt=0;
        min=new Entry();
        min->flag=-1;
        max=new Entry();
        max->flag=1;
        insert(ROOT,min);
        insert(ROOT,max);
    }

    /**
     * TODO Returns true if this map contains a mapping for the specified key.
     */
    bool containsKey(const K &key) const
    {
        return find(ROOT->child[1],key)!=NULL;
    }
    /**
     * TODO Returns true if this map maps one or more keys to the specified value.
     */
    bool containsValue(const V &value) const
    {
        return search(ROOT->child[1],value)!=NULL;
    }

    /**
     * TODO Returns a const reference to the value to which the specified key is mapped.
     * If the key is not present in this map, this function should throw ElementNotExist exception.
     * @throw ElementNotExist
     */
    const V &get(const K &key) const
    {
        if (containsKey(key))
        {
            Entry *t=find(ROOT->child[1],key);
            return t->value;
        }
        else throw ElementNotExist();
    }

    /**
     * TODO Returns true if this map contains no key-value mappings.
     */
    bool isEmpty() const
    {
        return cnt==0;
    }

    /**
     * TODO Associates the specified value with the specified key in this map.
     */


    /**
     * TODO Removes the mapping for the specified key from this map if present.
     * If there is no mapping for the specified key, throws ElementNotExist exception.
     * @throw ElementNotExist
     */
    void remove(const K &key)
    {
        if (containsKey(key))
        {
            Entry *t=find(ROOT->child[1],key);
            splay(t,ROOT->child[1]);
            cnt--;
            Entry *t1=t->child[0];
            while (t1->child[1]) t1=t1->child[1];
            Entry *t2=t->child[1];
            while (t2->child[0]) t2=t2->child[0];
            splay(t1,ROOT->child[1]);
            splay(t2,ROOT->child[1]->child[1]);
            ROOT->child[1]->child[1]->child[0]=NULL;
            delete t;
        }
        else throw ElementNotExist();
    }

    /**
     * TODO Returns the number of key-value mappings in this map.
     */
    int size() const
    {
        return cnt;
    }
};
template <class K, class V>
void TreeMap<K,V>::put(const K &key, const V &value)
{
    if (containsKey(key))
    {
        Entry *tmp=find(ROOT->child[1],key);
        tmp->value=value;
    }
    else
    {
        Entry *tmp=new Entry(key,value);
        insert(ROOT,tmp);
        cnt++;
    }
}
#endif
